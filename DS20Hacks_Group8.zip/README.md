# DSHacks20
Start app:
```
DSHacks20\api>npm run dev
```
